import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

import { Injectable } from '@angular/core';
import { Student } from './student.model';
import { Time } from '@angular/common';


@Injectable()
export class AppSrevice{

constructor(private http: HttpClient){}
editTime=new Subject<Student>();

findById(id:number) : Observable<Student>{
    return this.http.get<Student>('http://localhost:8083/getStudentDetailsById/'+id);
}
update(id:number, data:Student) : Observable<any>{
    return this.http.put<Student>('http://localhost:8083/updateStudentDetails/'+id, data);
}
save(Student:Student) : Observable<Student>{
    return this.http.post<Student>('http://localhost:8083/saveStudentDetails/',Student);
}
getAll() : Observable<Student[]>{
    return this.http.get<Student[]>('http://localhost:8083/getAllStudentDetails/');
}
deleteById(id:number) : Observable<any>{
    return this.http.delete<any>('http://localhost:8083/deleteStudentDetails/'+id);
}
}