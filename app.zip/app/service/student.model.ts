import { Time } from '@angular/common';

export class Student{
    constructor(public id:number, public firstName:string, public lastName:string, public usn:string, public branch:string, public marksObtainsOutOf:string,public mobileNumber:string,public emailId:string){}
}