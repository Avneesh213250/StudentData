import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Time } from '@angular/common';
import { AppSrevice } from '../service/app.service';
import { Student } from '../service/student.model';

@Component({
  selector: 'app-time-date',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  @ViewChild('demoForm') demoForm: NgForm;
  constructor(
    private router: Router,
    private route:ActivatedRoute,
    private service:AppSrevice){}

    firstName
    lastName
    usn
    branch
    marksObtainsOutOf
    mobileNumber
    emailId
  ngOnInit(): void {

  }

onSubmit() { 
  this.firstName=this.demoForm.value.firstName;
  this.lastName=this.demoForm.value.lastName;
  this.usn=this.demoForm.value.usn;
  this.branch=this.demoForm.value.branch;
  this.marksObtainsOutOf=this.demoForm.value.marksObtainsOutOf;
  this.mobileNumber=this.demoForm.value.mobileNumber;
  this.emailId=this.demoForm.value.emailId;
  console.log(this.demoForm.value);

  this.service.save(new Student(null,this.firstName, this.lastName,this.usn,this.branch,this.marksObtainsOutOf, this.mobileNumber,this.emailId)).subscribe(
    data=>{
      console.log(data);
      
      this.router.navigate(['getAll']);
    }
    
  );
  }
  onCancel(){

  }
}
