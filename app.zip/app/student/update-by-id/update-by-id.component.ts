import { Component, OnInit, ViewChild } from '@angular/core';
import { AppSrevice } from 'src/app/service/app.service';
import { Student } from 'src/app/service/student.model';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { Time } from '@angular/common';
import { element } from 'protractor';

import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-update-by-id',
  templateUrl: './update-by-id.component.html',
  styleUrls: ['./update-by-id.component.css']
})
export class UpdateByIdComponent implements OnInit {
 demoForm:FormGroup=new FormGroup({});
  constructor(private service:AppSrevice,
    private router:Router,
    private route: ActivatedRoute) { }
  testData:Student;
  flag=true;
testId:number;
firstName
lastName
usn
branch
marksObtainsOutOf
mobileNumber
emailId
  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      const id = +params['id'];
      this.testId=id;
      console.log(id);
      this.service.findById(id).subscribe(
        data=>{
          console.log(data);
          
          
          this.testData=data;
          console.log(this.testData);
           this.demoForm=new FormGroup({
             test:new FormGroup({
              firstName:new FormControl(this.testData.firstName),
              lastName:new FormControl(this.testData.lastName),
             }),
            
            usn:new FormControl(this.testData.usn),
            branch:new FormControl(this.testData.branch),
            marksObtainsOutOf:new FormControl(this.testData.marksObtainsOutOf),
            mobileNumber:new FormControl(this.testData.mobileNumber),
            emailId:new FormControl(this.testData.emailId)
      
      
    });
        }
      );
    });

    }
    fromJsonDate(jDate): string {
      const bDate: Date = new Date(jDate);
      return bDate.toISOString().substring(0, 10);  //Ignore time
    }
    temp:any;
    onUpdate(){
  
this.service.update(this.testId, new Student(null,this.demoForm.value.test.firstName, this.demoForm.value.test.lastName,this.demoForm.value.usn,this.demoForm.value.branch,this.demoForm.value.marksObtainsOutOf, this.demoForm.value.mobileNumber,this.demoForm.value.emailId)).subscribe(
  element=>{
   console.log(element);
   this.router.navigate(['getAll']);
    
  }
);
    }
    onCancel(){
      
    }
}
