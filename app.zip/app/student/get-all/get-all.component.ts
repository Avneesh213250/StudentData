import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/service/student.model';
import { AppSrevice } from 'src/app/service/app.service';
import { Router } from '@angular/router';


import { ExcelService } from 'src/app/service/excel.service';

@Component({
  selector: 'app-get-all',
  templateUrl: './get-all.component.html',
  styleUrls: ['./get-all.component.css']
})
export class GetAllComponent implements OnInit {

  Student:Student;
  constructor(private service:AppSrevice,
    private router:Router,
    private excelService:ExcelService) { }
    Students:Student[];

  ngOnInit(): void {
    localStorage.clear();
    this.service.getAll().subscribe(

      (element:Student[])=>{
        this.Students=element;
        
      }
    );
  }
  ondelete(index:number){
    let con=confirm('Are you sure?');
    if(con===true){
      this.Student=this.Students[index];
      console.log(this.Student.id);
      this.service.deleteById(this.Student.id).subscribe(
        data=>{
          alert("Successfully Deleted ");
          this.service.getAll().subscribe(
            (element:Student[])=>{
              this.Students=element;
            }
          );
        }
      );

    }
    
  }
  onEdit(index:number){
    this.Student=this.Students[index];
    console.log(this.Student);

    this.service.editTime.next(this.Student);
    this.router.navigate(['update',this.Student.id]);
  }
  exportAsXLSX():void {
   
    this.excelService.exportAsExcelFile(this.Students, 'salesList');
  }
}
