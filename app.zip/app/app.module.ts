import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component'; 
import { RouterModule, Routes} from '@angular/router';  


import { AppSrevice } from './service/app.service';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { StudentComponent } from './student/student.component';
import { GetAllComponent } from './student/get-all/get-all.component';
import { UpdateByIdComponent } from './student/update-by-id/update-by-id.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { ExcelService } from './service/excel.service';

const appRoute:Routes=[
  {path:'', redirectTo:'/create', pathMatch:'full'},
  {path:'create', component:StudentComponent},
  {path:'getAll', component:GetAllComponent},
  {path:'update/:id', component:UpdateByIdComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    GetAllComponent,
    HeaderComponent,
    UpdateByIdComponent,
    SideMenuComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoute,{useHash:true})
  ],
  exports: [RouterModule],
  providers: [AppSrevice, ExcelService],
  bootstrap: [AppComponent]
})
export class AppModule { }
